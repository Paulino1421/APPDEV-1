import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class FirePokemonService {
    getFirePokemon(){
    return [
      { name: 'Cyndaquil', hp: 39, atk: 52, def: 43, spa: 60, spd: 50, spe: 65, type: 'Fire', img: 'cyndaquil.png' ,ability: 'Blaze'},
      { name: 'Quilava', hp: 58, atk: 64, def: 58, spa: 80, spd: 65, spe: 80, type: 'Fire', img: 'quilava.png',ability: 'Blaze' },
      { name: 'Typhlosion', hp: 78, atk: 84, def: 78, spa: 109, spd: 85, spe: 100, type: 'Fire', img: 'typhlosion.png',ability: 'Blaze' }
    ];
  }
}
