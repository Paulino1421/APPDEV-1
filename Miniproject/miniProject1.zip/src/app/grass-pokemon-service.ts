import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class GrassPokemonService {
 getGrasspokemon(){
    return[
      { name: 'Chikorita', hp: 45, atk: 49, def: 65, spa: 49, spd: 65, spe: 45, type: 'Grass', img: 'chikorita.png',ability: 'Overgrow' },
      { name: 'Bayleef', hp: 60, atk: 62, def: 80, spa: 63, spd: 80, spe: 60, type: 'Grass', img: 'bayleef.png',ability: 'Overgrow' },
      { name: 'Meganium', hp: 80, atk: 82, def: 100, spa: 83, spd: 100, spe: 80, type: 'Grass', img: 'meganium.png',ability: 'Overgrow' }
    ];
  } 
}
