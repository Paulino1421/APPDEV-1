import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { FirePokemon } from './fire-pokemon/fire-pokemon';
import { WaterPokemon } from './water-pokemon/water-pokemon';
import { GrassPokemon } from './grass-pokemon/grass-pokemon';

const routes: Routes = [
  {path:'fire',component:FirePokemon},
  {path:'water',component:WaterPokemon},
  {path:'grass',component:GrassPokemon}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
