import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class WaterPokemonService {
  getWaterPokemon(){
    return [
      { name: 'Totodile', hp: 50, atk: 65, def: 64, spa: 44, spd: 48, spe: 43, type: 'Water' ,img: 'totodile.jpg',ability: 'Torrent' },
      { name: 'Croconaw', hp: 65, atk: 80, def: 80, spa: 59, spd: 63, spe: 58, type: 'Water', img: 'croconaw.png',ability: 'Torrent'  },
      { name: 'Feraligatr', hp: 85, atk: 105, def: 100, spa: 79, spd: 83, spe: 78, type: 'Water',img: 'feraligatr.png',ability: 'Torrent' }
    ];
  }
}
