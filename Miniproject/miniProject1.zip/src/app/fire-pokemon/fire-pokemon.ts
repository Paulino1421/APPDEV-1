import { Component } from '@angular/core';
import { FirePokemonService } from '../fire-pokemon-service';

@Component({
  selector: 'app-fire-pokemon',
  standalone: false,
  templateUrl: './fire-pokemon.html',
  styleUrl: './fire-pokemon.css'
})
export class FirePokemon {
firePokemon:{name:string,hp:number,atk:number,def:number,spa:number,spd:number,spe:number,type:string,img:string,ability: string }[]=[];
constructor(private water:FirePokemonService){}
ngOnInit():void{
  this.firePokemon=this.water.getFirePokemon();
}

index = 0;

evolve(){
  if(this.index < this.water.getFirePokemon().length-1)this.index++;
}

revert(){
  if(this.index >0)this.index--;
}
}
