import { Component } from '@angular/core';
import { GrassPokemonService } from '../grass-pokemon-service';

@Component({
  selector: 'app-grass-pokemon',
  standalone: false,
  templateUrl: './grass-pokemon.html',
  styleUrl: './grass-pokemon.css'
})
export class GrassPokemon {
grassPokemon:{name:string,hp:number,atk:number,def:number,spa:number,spd:number,spe:number,type:string,img:string,ability: string }[]=[];
constructor(private water:GrassPokemonService){}
ngOnInit():void{
  this.grassPokemon=this.water.getGrasspokemon();
}

index = 0;

evolve(){
  if(this.index < this.water.getGrasspokemon().length-1)this.index++;
}

revert(){
  if(this.index >0)this.index--;
}
}
