import { Component } from '@angular/core';
import { WaterPokemonService } from '../water-pokemon-service';

@Component({
  selector: 'app-water-pokemon',
  standalone: false,
  templateUrl: './water-pokemon.html',
  styleUrl: './water-pokemon.css'
})
export class WaterPokemon {
waterPokemon:{name:string,hp:number,atk:number,def:number,spa:number,spd:number,spe:number,type:string,img:string,ability: string }[]=[];
constructor(private water:WaterPokemonService){}
ngOnInit():void{
  this.waterPokemon=this.water.getWaterPokemon();
}

index = 0;

evolve(){
  if(this.index < this.water.getWaterPokemon().length-1)this.index++;
}

revert(){
  if(this.index >0)this.index--;
}
}
