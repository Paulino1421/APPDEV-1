import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class PokeballService {
  getPokeBalls(){
    return[
       {
        ball: "Poke Ball",
        effect: "Standard ball with a normal catch rate (x1)",
        origin: "The most basic and iconic Poké Ball"
      },
      {
        ball: "Great Ball",
        effect: "Higher catch rate than a Poke Ball (x1.5)",
        origin: "Improved version of the Poke Ball"
      },
      {
        ball: "Ultra Ball",
        effect: "Higher catch rate than a Great Ball (x2)",
        origin: "High-performance Poké Ball used for stronger Pokémon"
      },
      {
        ball: "Master Ball",
        effect: "Guarantees a 100% catch rate on any Pokémon",
        origin: "Rare prototype ball, typically given only once in-game"
      },
      {
        ball: "Quick Ball",
        effect: "Very high catch rate when used at the start of battle",
        origin: "Designed to catch Pokémon quickly in early turns"
      },
      {
        ball: "Dusk Ball",
        effect: "High catch rate in caves or at night",
        origin: "Made for nighttime or dark area hunting"
      },
      {
        ball: "Timer Ball",
        effect: "Increases catch rate the longer the battle goes on",
        origin: "Rewards patience in long battles"
      },
      {
        ball: "Net Ball",
        effect: "More effective on Water- and Bug-type Pokémon",
        origin: "Has a net-like design for aquatic or insect Pokémon"
      },
      {
        ball: "Dive Ball",
        effect: "Higher catch rate for Pokémon found while fishing or underwater",
        origin: "Meant for underwater Pokémon"
      },
      {
        ball: "Luxury Ball",
        effect: "Makes Pokémon grow friendlier faster",
        origin: "Premium design to promote friendship"
      },
      {
        ball: "Heal Ball",
        effect: "Heals HP and status of caught Pokémon immediately",
        origin: "Designed to care for Pokémon from the start"
      },
      {
        ball: "Repeat Ball",
        effect: "Higher catch rate for Pokémon already registered in Pokédex",
        origin: "Helps catch duplicates more easily"
      },
      {
        ball: "Nest Ball",
        effect: "More effective on low-level Pokémon",
        origin: "Ideal for catching weaker Pokémon early on"
      },
      {
        ball: "Premier Ball",
        effect: "Same as a Poke Ball but with a special white design",
        origin: "Bonus ball given when buying 10 Poke Balls"
      }
    ]
  }
}
