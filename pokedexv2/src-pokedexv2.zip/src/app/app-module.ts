import { NgModule, provideBrowserGlobalErrorListeners } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing-module';
import { App } from './app';
import { Bugsy } from './bugsy/bugsy';
import { Falkner } from './falkner/falkner';
import { Chuck } from './chuck/chuck';
import { Clair } from './clair/clair';
import { Jasmine } from './jasmine/jasmine';
import { Morty } from './morty/morty';
import { Nav } from './nav/nav';
import { Pryce } from './pryce/pryce';
import { Whitney } from './whitney/whitney';
import { TrainerForm } from './trainer-form/trainer-form';
import { Pokeballs } from './pokeballs/pokeballs';
import { Berry } from './berry/berry';
import { MatTableModule } from '@angular/material/table';
import { MatDivider } from '@angular/material/divider';
import { BothTables } from './both-tables/both-tables';
import  {ReactiveFormsModule} from '@angular/forms';
import { PokemonCharizard } from './pokemon-charizard/pokemon-charizard';
import { PokemonGengar } from './pokemon-gengar/pokemon-gengar';
import { PokemonTogepi } from './pokemon-togepi/pokemon-togepi';
import { PokemonLugia } from './pokemon-lugia/pokemon-lugia';
import { PokemonSlowKing } from './pokemon-slow-king/pokemon-slow-king';
import { PokemonHooh } from './pokemon-hooh/pokemon-hooh';
import { Favoritepokemon } from './favoritepokemon/favoritepokemon'
import {HttpClientModule} from '@angular/common/http'

@NgModule({
  declarations: [
    App,
    Bugsy,
    Falkner,
    Chuck,
    Clair,
    Jasmine,
    Morty,
    Nav,
    Pryce,
    Whitney,
    TrainerForm,
    Pokeballs,
    Berry,
    BothTables,
    PokemonCharizard,
    PokemonGengar,
    PokemonTogepi,
    PokemonLugia,
    PokemonSlowKing,
    PokemonHooh,
    Favoritepokemon
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    ReactiveFormsModule,
    MatTableModule,
    HttpClientModule,
    MatDivider,
    
    
    
  ],
  providers: [
    provideBrowserGlobalErrorListeners()
  ],
  bootstrap: [App]
})
export class AppModule { }
