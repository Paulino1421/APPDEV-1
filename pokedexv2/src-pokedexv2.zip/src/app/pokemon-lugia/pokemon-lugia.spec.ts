import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PokemonLugia } from './pokemon-lugia';

describe('PokemonLugia', () => {
  let component: PokemonLugia;
  let fixture: ComponentFixture<PokemonLugia>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [PokemonLugia]
    })
    .compileComponents();

    fixture = TestBed.createComponent(PokemonLugia);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
