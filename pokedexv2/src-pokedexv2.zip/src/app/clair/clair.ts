import { Component } from '@angular/core';
import { GymLeader } from '../gym-leader';

@Component({
  selector: 'app-clair',
  standalone: false,
  templateUrl: './clair.html',
  styleUrl: './clair.css'
})
export class Clair {
clair:{pokemon:string;level:string;type:string}[]=[];
constructor(private gymService :GymLeader){}

ngOnInit():void{
  this.clair=this.gymService.getClair();
}
}
