import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PokemonGengar } from './pokemon-gengar';

describe('PokemonGengar', () => {
  let component: PokemonGengar;
  let fixture: ComponentFixture<PokemonGengar>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [PokemonGengar]
    })
    .compileComponents();

    fixture = TestBed.createComponent(PokemonGengar);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
