import { Component, NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { Bugsy } from './bugsy/bugsy';
import { combineLatest } from 'rxjs';
import { Chuck } from './chuck/chuck';
import { Clair } from './clair/clair';
import { Falkner } from './falkner/falkner';
import { Jasmine } from './jasmine/jasmine';
import { Morty } from './morty/morty';
import { Pryce } from './pryce/pryce';
import { Whitney } from './whitney/whitney';
import { TrainerForm } from './trainer-form/trainer-form';
import { Berry } from './berry/berry';
import { Pokeballs } from './pokeballs/pokeballs';
import { BothTables } from './both-tables/both-tables';
import { Favoritepokemon } from './favoritepokemon/favoritepokemon';
import { PokemonCharizard } from './pokemon-charizard/pokemon-charizard';
import { PokemonGengar } from './pokemon-gengar/pokemon-gengar';
import { PokemonTogepi } from './pokemon-togepi/pokemon-togepi';
import { PokemonLugia } from './pokemon-lugia/pokemon-lugia';
import { PokemonSlowKing } from './pokemon-slow-king/pokemon-slow-king';
import { PokemonHooh } from './pokemon-hooh/pokemon-hooh';

const routes: Routes = [
  {path:"bugsy",component:Bugsy},
  {path:"chuck",component:Chuck},
  {path:"clair",component:Clair},
  {path:"falkner",component:Falkner},
  {path:"jasmine",component:Jasmine},
  {path:"morty",component:Morty},
  {path:"pryce",component:Pryce},
  {path:"whitney",component:Whitney},
  {path:"form",component:TrainerForm},
  {path:"berry",component:Berry},
  {path:"pokeballs",component:Pokeballs},
  {path:"both",component:BothTables},
  {path:"fpokemon",component:Favoritepokemon},
  {path:"charizard",component:PokemonCharizard},
  {path:"gengar",component:PokemonGengar},
  {path:"togepi",component:PokemonTogepi},
  {path:"lugia",component:PokemonLugia},
  {path:"slowking",component:PokemonSlowKing},
  {path:"hooh",component:PokemonHooh},
  
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
  
})
export class AppRoutingModule { }
