import { Component } from '@angular/core';
import { GymLeader } from '../gym-leader';
@Component({
  selector: 'app-whitney',
  standalone: false,
  templateUrl: './whitney.html',
  styleUrl: './whitney.css'
})
export class Whitney {
whitney:{pokemon:string;level:string;type:string}[]=[];
constructor(private gymService: GymLeader){}

ngOnInit():void{
  this.whitney=this.gymService.getWhitney();
}
}
