import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class GymLeader {
   getFalkner() {
  return [
    { pokemon: "Pidgey", level: "9", type: "Flying" },
    { pokemon: "Pidgeotto", level: "13", type: "Flying" }
  ];
}

getBugsy() {
  return [
    { pokemon: "Metapod", level: "14", type: "Bug" },
    { pokemon: "Kakuna", level: "14", type: "Bug" },
    { pokemon: "Scyther", level: "17", type: "Bug" }
  ];
}

getWhitney() {
  return [
    { pokemon: "Clefairy", level: "18", type: "Normal" },
    { pokemon: "Miltank", level: "20", type: "Normal" }
  ];
}

getMorty() {
  return [
    { pokemon: "Gastly", level: "21", type: "Ghost" },
    { pokemon: "Haunter", level: "21", type: "Ghost" },
    { pokemon: "Gengar", level: "25", type: "Ghost" }
  ];
}

getChuck() {
  return [
    { pokemon: "Primeape", level: "27", type: "Fighting" },
    { pokemon: "Poliwrath", level: "30", type: "Water/Fighting" }
  ];
}

getJasmine() {
  return [
    { pokemon: "Magnemite", level: "30", type: "Electric/Steel" },
    { pokemon: "Steelix", level: "35", type: "Steel/Ground" }
  ];
}

getPryce() {
  return [
    { pokemon: "Seel", level: "27", type: "Water" },
    { pokemon: "Dewgong", level: "29", type: "Water/Ice" },
    { pokemon: "Piloswine", level: "31", type: "Ice/Ground" }
  ];
}

getClair() {
  return [
    { pokemon: "Dragonair", level: "37", type: "Dragon" },
    { pokemon: "Dragonair", level: "37", type: "Dragon" },
    { pokemon: "Kingdra", level: "40", type: "Water/Dragon" }
  ];
}
}
