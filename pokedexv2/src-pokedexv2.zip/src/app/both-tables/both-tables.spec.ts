import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BothTables } from './both-tables';

describe('BothTables', () => {
  let component: BothTables;
  let fixture: ComponentFixture<BothTables>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [BothTables]
    })
    .compileComponents();

    fixture = TestBed.createComponent(BothTables);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
