import { Component } from '@angular/core';

@Component({
  selector: 'app-both-tables',
  standalone: false,
  templateUrl: './both-tables.html',
  styleUrl: './both-tables.css'
})
export class BothTables {

}
