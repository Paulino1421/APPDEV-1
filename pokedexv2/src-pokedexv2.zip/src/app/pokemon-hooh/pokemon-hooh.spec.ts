import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PokemonHooh } from './pokemon-hooh';

describe('PokemonHooh', () => {
  let component: PokemonHooh;
  let fixture: ComponentFixture<PokemonHooh>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [PokemonHooh]
    })
    .compileComponents();

    fixture = TestBed.createComponent(PokemonHooh);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
