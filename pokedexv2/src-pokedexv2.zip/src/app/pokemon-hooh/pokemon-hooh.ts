import { Component } from '@angular/core';
import {HttpClient} from '@angular/common/http'
@Component({
  selector: 'app-pokemon-hooh',
  standalone: false,
  templateUrl: './pokemon-hooh.html',
  styleUrl: './pokemon-hooh.css'
})
export class PokemonHooh {
  pokemon: any;
  constructor(private http: HttpClient) {
  this.http.get('https://pokeapi.co/api/v2/pokemon/ho-oh').subscribe (response => {this.pokemon = response;},
  error => {console.error('Error:', error);
  //You can handle errors in this block
  }
  );
  }
}
