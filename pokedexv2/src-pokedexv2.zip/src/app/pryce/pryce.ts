import { Component } from '@angular/core';
import { GymLeader } from '../gym-leader';
@Component({
  selector: 'app-pryce',
  standalone: false,
  templateUrl: './pryce.html',
  styleUrl: './pryce.css'
})
export class Pryce {
pryce:{pokemon:string;level:string;type:string}[]=[];
constructor(private gymService: GymLeader){}

ngOnInit():void{
  this.pryce=this.gymService.getPryce();
}
}
