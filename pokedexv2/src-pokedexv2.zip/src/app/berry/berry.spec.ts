import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Berry } from './berry';

describe('Berry', () => {
  let component: Berry;
  let fixture: ComponentFixture<Berry>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [Berry]
    })
    .compileComponents();

    fixture = TestBed.createComponent(Berry);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
