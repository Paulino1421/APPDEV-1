import { Component } from '@angular/core';
import { BerryService } from '../berry-service';

@Component({
  selector: 'app-berry',
  standalone: false,
  templateUrl: './berry.html',
  styleUrl: './berry.css'
})
export class Berry {

  dataSource: { berry: string; effect: string; origin: string }[] = [];

  constructor(private berries:BerryService){}

  ngOnInit(): void {
    console.log('ngOnInit called');
   this.dataSource = this.berries.getBerries();
}
displayedColumns: string[] = ['berry', 'effect', 'origin'];  // <-- add this
}
