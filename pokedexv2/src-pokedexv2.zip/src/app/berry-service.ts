import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class BerryService {
  getBerries(){
  return [
   {
        berry: "Cheri Berry",
        effect: "Recovers Pokémon from being paralyzed",
        origin: "Based on the real cherry"
      },
      {
        berry: "Chesto Berry",
        effect: "Cures sleep instantly when held",
        origin: "Based on a chestnut"
      },
      {
        berry: "Pecha Berry",
        effect: "Recovers Pokémon from being poisoned",
        origin: "Based on a peach"
      },
      {
        berry: "Rawst Berry",
        effect: "Heals a Pokémon from a burn",
        origin: "Possibly based on a raspberry"
      },
      {
        berry: "Aspear Berry",
        effect: "Thaws a frozen Pokémon",
        origin: "Based on a pear"
      },
      {
        berry: "Leppa Berry",
        effect: "Restores 10 PP to a move when used",
        origin: "Possibly based on an apple"
      },
      {
        berry: "Oran Berry",
        effect: "Restores 10 HP when held",
        origin: "Combination of orange and berry"
      },
      {
        berry: "Sitrus Berry",
        effect: "Restores 25% of max HP when held",
        origin: "Based on citrus fruits"
      },
      {
        berry: "Lum Berry",
        effect: "Cures any major status condition",
        origin: "Possibly based on plum or luminous"
      },
      {
        berry: "Figy Berry",
        effect: "Restores 33% HP but may confuse if Nature dislikes spicy",
        origin: "Based on fig fruit"
      }
  
]
}
}
