import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PokemonSlowKing } from './pokemon-slow-king';

describe('PokemonSlowKing', () => {
  let component: PokemonSlowKing;
  let fixture: ComponentFixture<PokemonSlowKing>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [PokemonSlowKing]
    })
    .compileComponents();

    fixture = TestBed.createComponent(PokemonSlowKing);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
