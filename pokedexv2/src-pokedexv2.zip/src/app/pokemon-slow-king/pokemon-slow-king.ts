import { Component } from '@angular/core';
import {HttpClient} from '@angular/common/http'
@Component({
  selector: 'app-pokemon-slow-king',
  standalone: false,
  templateUrl: './pokemon-slow-king.html',
  styleUrl: './pokemon-slow-king.css'
})
export class PokemonSlowKing {
  pokemon: any;

  constructor(private http: HttpClient) {}

  ngOnInit() {
    this.http.get('https://pokeapi.co/api/v2/pokemon/slowking').subscribe(
      response => {
        this.pokemon = response;
      },
      error => {
        console.error('Error:', error);
      }
    );
  }
}
