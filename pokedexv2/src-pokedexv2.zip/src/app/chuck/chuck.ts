import { Component } from '@angular/core';
import { GymLeader } from '../gym-leader';

@Component({
  selector: 'app-chuck',
  standalone: false,
  templateUrl: './chuck.html',
  styleUrl: './chuck.css'
})
export class Chuck {
chuck : {pokemon :string; level: string; type :string}[]=[];
constructor(private gymService: GymLeader){}
ngOnInit():void{
  this.chuck=this.gymService.getChuck();
}
}
