import { Component } from '@angular/core';
import { GymLeader } from '../gym-leader';

@Component({
  selector: 'app-falkner',
  standalone: false,
  templateUrl: './falkner.html',
  styleUrl: './falkner.css'
})
export class Falkner {
falkner: { pokemon: string; level: string; type: string }[] = [];

  constructor(private gymService: GymLeader) {}

  ngOnInit(): void {
    this.falkner = this.gymService.getFalkner();
  }
}
