import { Component } from '@angular/core';
import { GymLeader } from '../gym-leader';

@Component({
  selector: 'app-morty',
  standalone: false,
  templateUrl: './morty.html',
  styleUrl: './morty.css'
})
export class Morty {
morty:{pokemon:string;level:string;type:string}[]=[];
constructor(private gymService: GymLeader){}

ngOnInit():void{
  this.morty=this.gymService.getMorty();
}
}
