import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Favoritepokemon } from './favoritepokemon';

describe('Favoritepokemon', () => {
  let component: Favoritepokemon;
  let fixture: ComponentFixture<Favoritepokemon>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [Favoritepokemon]
    })
    .compileComponents();

    fixture = TestBed.createComponent(Favoritepokemon);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
