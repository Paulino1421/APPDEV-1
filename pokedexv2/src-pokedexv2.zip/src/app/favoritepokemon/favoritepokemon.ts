import { Component } from '@angular/core';

@Component({
  selector: 'app-favoritepokemon',
  standalone: false,
  templateUrl: './favoritepokemon.html',
  styleUrl: './favoritepokemon.css'
})
export class Favoritepokemon {

}
