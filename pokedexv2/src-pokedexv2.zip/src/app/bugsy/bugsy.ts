import { Component } from '@angular/core';
import { GymLeader } from '../gym-leader';
@Component({
  selector: 'app-bugsy',
  standalone: false,
  templateUrl: './bugsy.html',
  styleUrl: './bugsy.css'
})
export class Bugsy {
bugsy :{pokemon :string; level: string; type :string}[]=[];

constructor (private gymService : GymLeader){}

ngOnInit():void{
  this.bugsy= this.gymService.getBugsy();
}
}
