import { Component } from '@angular/core';
import { PokeballService } from '../pokeball-service';

@Component({
  selector: 'app-pokeballs',
  standalone: false,
  templateUrl: './pokeballs.html',
  styleUrl: './pokeballs.css'
})
export class Pokeballs {
dataSource: { ball: string; effect: string; origin: string }[] = [];

  constructor( private balls:PokeballService){};

  ngOnInit(): void {
  console.log('ngOnInit called');
 this.dataSource= this.balls.getPokeBalls();
}
displayedColumns: string[] = ['ball', 'effect','origin']
}
