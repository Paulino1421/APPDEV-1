import { Component } from '@angular/core';
import { GymLeader } from '../gym-leader';

@Component({
  selector: 'app-jasmine',
  standalone: false,
  templateUrl: './jasmine.html',
  styleUrl: './jasmine.css'
})
export class Jasmine {
jasmine: { pokemon: string; level: string; type: string}[]=[];

constructor (private gymService : GymLeader){}
ngOnInit():void{
  this.jasmine = this.gymService.getJasmine();
}
}
