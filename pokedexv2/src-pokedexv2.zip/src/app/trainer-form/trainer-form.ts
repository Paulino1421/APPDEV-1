import { Component } from '@angular/core';
import { FormGroup,FormControl,ReactiveFormsModule } from '@angular/forms';
type PokiForm ={
  name : string ;
  age : string;
  address: string;
  pokemon1:string;
  pokemon2:string;
  pokemon3:string;
  pokemon4:string;
  pokemon5:string;
  pokemon6:string;
  
};
@Component({
  selector: 'app-trainer-form',
  standalone: false,
  templateUrl: './trainer-form.html',
  styleUrl: './trainer-form.css'
})
export class TrainerForm {
poketrainer:  PokiForm []=[
  {name: "", age: "", address: "", pokemon1:"",pokemon2:"",pokemon3:"",pokemon4:"",pokemon5:"",pokemon6:"", }
];
formGroup =  new FormGroup({
  name : new FormControl('',{nonNullable: true}),
  age :    new FormControl('',{nonNullable: true}), 
  address: new FormControl('',{nonNullable: true}),
  pokemon1:new FormControl('',{nonNullable: true}),
  pokemon2:new FormControl('',{nonNullable: true}),
  pokemon3:new FormControl('',{nonNullable: true}),
  pokemon4:new FormControl('',{nonNullable: true}),
  pokemon5:new FormControl('',{nonNullable: true}),
  pokemon6:new FormControl('',{nonNullable: true})
});
onSubmit(){
    const PokiForm = this.formGroup.getRawValue();
    this.poketrainer.push(PokiForm);
    //Reset after submition
    this.formGroup.controls['name'].setValue('');
    this.formGroup.controls['age'].setValue('');
    this.formGroup.controls['address'].setValue('');
    this.formGroup.controls['pokemon1'].setValue('');
    this.formGroup.controls['pokemon2'].setValue('');
    this.formGroup.controls['pokemon3'].setValue('');
    this.formGroup.controls['pokemon4'].setValue('');
    this.formGroup.controls['pokemon5'].setValue('');
    this.formGroup.controls['pokemon6'].setValue('');
    
  }
}
