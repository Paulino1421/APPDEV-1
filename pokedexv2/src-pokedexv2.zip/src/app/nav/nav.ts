import { Component } from '@angular/core';

@Component({
  selector: 'app-nav',
  standalone: false,
  templateUrl: './nav.html',
  styleUrl: './nav.css'
})
export class Nav {
    // Boolean to track the sidebar's open/close state
    isSidebarOpen = false;

    // Toggle the sidebar's visibility
    toggleSidebar(): void {
      this.isSidebarOpen = !this.isSidebarOpen;
    }
}
