import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PokemonTogepi } from './pokemon-togepi';

describe('PokemonTogepi', () => {
  let component: PokemonTogepi;
  let fixture: ComponentFixture<PokemonTogepi>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [PokemonTogepi]
    })
    .compileComponents();

    fixture = TestBed.createComponent(PokemonTogepi);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
