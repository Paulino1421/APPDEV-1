import { Component } from '@angular/core';
import { HttpClient} from '@angular/common/http';
@Component({
  selector: 'app-pokemon-togepi',
  standalone: false,
  templateUrl: './pokemon-togepi.html',
  styleUrl: './pokemon-togepi.css'
})
export class PokemonTogepi {
  pokemon: any;

  constructor(private http: HttpClient) {}

  ngOnInit() {
    this.http.get('https://pokeapi.co/api/v2/pokemon/togepi').subscribe(
      response => {
        this.pokemon = response;
      },
      error => {
        console.error('Error:', error);
      }
    );
  }
}
