import { Component } from '@angular/core';

@Component({
  selector: 'app-body',
  standalone: false,
  templateUrl: './body.component.html',
  styleUrl: './body.component.css'
})
export class BodyComponent {
profile = {
  name: "Jayson Errrol Dela Cruz Paulino",
  address : "NPC Iris Ville, Irisan Baguoi City",
  contact:{
    email:'123@gmail.com',
    phone:'+22 (244) 2323',
    location:'earth',
  }
}
educationalbackground = {
  preschool:"N/A",
  elementary : "Step Learning Acadamy",
  highschool:'immacaulate School',
  collage1:'Universaty of baguio',
  collage2:'Acatech Avaation support',
}
experiences = {
  ojt :'OMNI Aviation',
  position: 'Mechanic apprentice',
  duration:'January 14 2018 - October 20 2018',
  
}

currenteducation={
  cSchool:'Unviversaty of baguio',
  Year:'2nd',
  Course: 'Bachelor of Science in Computer Science' 
}

}
