import { Component } from '@angular/core';

@Component({
  selector: 'app-body',
  standalone: false,
  templateUrl: './body.component.html',
  styleUrl: './body.component.css'
})
export class BodyComponent {
specification={
 SwitchType: "Cherry MX Red (Mechanical)",
 KeyLayout: "Full-size (104 keys)",
 Backlighting: "RGB with customizable colors",
 Connectivity: "Wired (USB 2.0)",
 Dimensions: "440 mm x 135 mm x 35 mm",
 Weight:" 1.2 kg",
 CableLength: "1.8 meters",
 AdditionalFeatures: "Anti-ghosting, N-key rollover, dedicated media controls",
}
inthebox={
  model:"KB-x1000 Keyboard",
  cable:'usb cable',
  manual:'manual',
  tools:'keycap Remover tool',
  warranty:'warranty card',
}
product={
  
}

}
