import { Component } from '@angular/core';

@Component({
  selector: 'app-head',
  standalone: false,
  templateUrl: './head.component.html',
  styleUrl: './head.component.css'
})
export class HeadComponent {
product={
 model : 'KB-x1000 Keyboard', 
}
}
